package com.example.cuctest;

public class Belly {
    public void eat(int cukes) {

    }
}
