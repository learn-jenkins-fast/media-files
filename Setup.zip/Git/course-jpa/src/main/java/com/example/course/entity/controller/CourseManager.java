package com.example.course.entity.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.example.course.entity.Course;

public class CourseManager {
	Logger logger = Logger.getLogger(CourseManager.class.getName());
	private static CourseManager courseManager = new CourseManager();
	private CourseManager() {
		Course course=getNewCourse();
		course.setCode("E650");
		course.setDescription("Enterprise Application Development in Java");
		course.setFee(1000);
		course.setDuration(5);
		courses.put(course.getCode(), course);
	}
	public static CourseManager getCourseManager() {
		return courseManager;
	}
	Map<String, Course> courses = new HashMap<String, Course>();
	public Course getNewCourse() {
		return new Course();
	}
	public String createCourse(Course course) throws Exception {
		logger.info("create course="+course);
		boolean foundCourse = courses.containsKey(course.getCode());
		String message = "Course Created";
		if (foundCourse) {
				message = "Course already exists";
			}
		else {
			courses.put(course.getCode(), course);
		}
		return message;
	}
	public String deleteCourse(Course course) throws Exception {
		logger.info("delete course="+course);
		    if (courses.containsKey(course.getCode())) {
		    	courses.remove(course.getCode());
				return "Removed";
		    } else {
		    	return "Not Found";
		    }
	}
	public String updateCourse(Course course) throws Exception {
		logger.info("update course="+course);
		courses.put(course.getCode(), course);
			return "";
	}
	public List<Course> getCourseByCode(String code)  {
		logger.info("get code="+code);
		Course course = null;
		List<Course> courseList = new ArrayList<Course>();
		if (courses.containsKey(code)) {
			System.out.println("found");
			courseList.add(courses.get(code));
		}
		return courseList;
	}
}
